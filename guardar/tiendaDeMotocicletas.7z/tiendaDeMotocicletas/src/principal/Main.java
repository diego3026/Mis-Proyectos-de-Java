/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package principal;

import clases.TiendaDeMotos;
import clases.Validacion;
import java.util.Scanner;

/**
 *
 * @author asus
 */
public class Main {
    public static void main(String[] args) throws Validacion {
        TiendaDeMotos tienda = new TiendaDeMotos("Motos el diego");
        Scanner lector = new Scanner(System.in);
        
        String menu = "1.Agregar una motocicleta\n2.Mostrar\n3.Vender motocicleta\n4.Actualizar precio\n5.Salir";
        int opcion;
        
        fin:do{
            System.out.println(menu);
            opcion = lector.nextInt();
            
            switch(opcion){
                case 1 -> {
                    a:while(true){
                        try{
                            System.out.println("\nIngrese el numero de serie: ");
                            int numeroDeSerie = lector.nextInt();
                            System.out.println("\nIngrese el modelo: ");
                            int modelo = lector.nextInt();
                            System.out.println("\nIngrese la marca: ");
                            String marca = lector.next();
                            System.out.println("\nIngrese el precio: ");
                            double precio = lector.nextDouble();
                            System.out.println("\n");
                            
                            tienda.agregarMotocicleta(numeroDeSerie, modelo, marca, precio);
                            System.out.println("La moto se ha agregado exitosamente\n");
                            break a;
                        }catch(Exception e){
                            System.err.println(e.getMessage());
                            System.out.println("¿Desea continuar? responda si o no");
                            String continuar = lector.next();
                            if(continuar.equalsIgnoreCase("no")){
                                break a;
                            }
                        }
                    }
                    break;
                }
                case 2 -> {
                    System.out.println("\n"+tienda.listaDeMotocicletas());
                    break;
                }
                case 3 -> {
                    b:while(true){
                        try{
                            System.out.println("\nIngrese el numero de serie: ");
                            int numeroDeSerie = lector.nextInt();
                            
                            tienda.venderMotocicleta(numeroDeSerie);
                            System.out.println("La moto se ha vendido exitosamente\n");
                            break b;
                        }catch(Exception e){
                            System.err.println(e.getMessage());
                            System.out.println("¿Desea continuar? responda si o no");
                            String continuar = lector.next();
                            if(continuar.equalsIgnoreCase("no")){
                                break b;
                            }
                        }
                    }   
                    break;
                }
                case 4 -> {
                    b:while(true){
                        try{
                            System.out.println("\nIngrese el numero de serie: ");
                            int numeroDeSerie = lector.nextInt();
                            System.out.println("\nIngrese el nuevo precio: ");
                            double precioNuevo = lector.nextDouble();

                            tienda.actualizarPrecioMotocicleta(numeroDeSerie, precioNuevo);
                            System.out.println("El precio se ha actualizado correctamente\n");
                            break b;
                        }catch(Exception e){
                            System.err.println(e.getMessage());
                            System.out.println("¿Desea continuar? responda si o no");
                            String continuar = lector.next();
                            if(continuar.equalsIgnoreCase("no")){
                                break b;
                            }
                        }
                    }
                    break;
                }
                case 5 -> {
                    break fin;
                }
            }
        }while(true);
    }    
}
